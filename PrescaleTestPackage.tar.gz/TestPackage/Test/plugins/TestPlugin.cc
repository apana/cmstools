//
#include "FWCore/Framework/interface/EDAnalyzer.h"
#include "FWCore/Framework/interface/Event.h"
#include "FWCore/ParameterSet/interface/ParameterSet.h"


#include "HLTrigger/HLTcore/interface/HLTPrescaleProvider.h"
#include "CondFormats/DataRecord/interface/L1TGlobalPrescalesVetosRcd.h"
//
class TestPlugin : public edm::EDAnalyzer {

public:

  TestPlugin (const edm::ParameterSet &);
  virtual void analyze(const edm::Event&, const edm::EventSetup&);
  virtual void beginJob();
  virtual void endJob();
  virtual void beginRun(edm::Run const&, edm::EventSetup const&);
  virtual ~TestPlugin (void);

private:

  HLTPrescaleProvider *_hltConf;

};

TestPlugin::TestPlugin( const edm::ParameterSet & cfg )
{
  _hltConf= new HLTPrescaleProvider(cfg, consumesCollector(), *this);
}

TestPlugin::~TestPlugin (void)
{

  delete _hltConf;
}

void TestPlugin::beginJob() {}

void TestPlugin::beginRun(edm::Run const&run, edm::EventSetup const& setup)
{
  std::cout<<"New Run: "<<run.id().run()<<" "<<_hltConf->l1tGlobalUtil().numberOfPreScaleColumns()
           <<" "<<_hltConf->l1tGlobalUtil().prescaleColumn()<<std::endl;

  bool hasChanged=false;
  _hltConf->init(run,setup,"HLT",hasChanged);
}

void TestPlugin::analyze (const edm::Event & ev, const edm::EventSetup & setup)
{
  std::cout<<"New Event: "<<_hltConf->l1tGlobalUtil().numberOfPreScaleColumns()
           <<" "<<_hltConf->l1tGlobalUtil().prescaleColumn()<<std::endl;

  const_cast<l1t::L1TGlobalUtil *>(&_hltConf->l1tGlobalUtil())->retrieveL1Event(ev,setup);

  std::cout<<"           "<<_hltConf->l1tGlobalUtil().numberOfPreScaleColumns()
           <<" "<<_hltConf->l1tGlobalUtil().prescaleColumn()<<std::endl;
}

void TestPlugin::endJob() {}
//-----------------------------------------------------------------------
#include "FWCore/Framework/interface/MakerMacros.h"
DEFINE_FWK_MODULE(TestPlugin);
//=======================================================================
