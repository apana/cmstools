#
import FWCore.ParameterSet.Config as cms

process = cms.Process("Test")

process.load("Configuration.Geometry.GeometryRecoDB_cff")
process.load("Configuration.StandardSequences.MagneticField_cff")

process.load('Configuration.StandardSequences.FrontierConditions_GlobalTag_condDBv2_cff')


process.source = cms.Source("PoolSource",
                            inputCommands = cms.untracked.vstring('keep *')
                            )

process.GlobalTag.globaltag = cms.string('92X_dataRun2_HLT_v4')

process.maxEvents = cms.untracked.PSet(input = cms.untracked.int32(1000))
process.source.skipEvents = cms.untracked.uint32(104000)

process.load("FWCore.MessageLogger.MessageLogger_cfi")
process.MessageLogger.cerr.FwkReport.reportEvery = 200
process.options   = cms.untracked.PSet( wantSummary = cms.untracked.bool(True) )

process.source.fileNames = cms.untracked.vstring (
    'root://cms-xrd-global.cern.ch//store/data/Run2017C/SingleMuon/MINIAOD/PromptReco-v2/000/300/400/00000/18F1B9B3-DD7B-E711-8B36-02163E01A494.root',
    'root://cms-xrd-global.cern.ch//store/data/Run2017C/SingleMuon/MINIAOD/PromptReco-v2/000/300/461/00000/3E7AF70D-237C-E711-9542-02163E0119AD.root'
)

#
process.testPlugin = cms.EDAnalyzer('TestPlugin')

process.TestPath = cms.Path(process.testPlugin)
#
