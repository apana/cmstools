#include "combineHists.h"

int main(int argc, char ** argv){

  using namespace std;

  //cout << "Number of command line args: " << argc <<endl;
  if ( argc < 4 ) {
    cout << "Please supply input filelist name, list of histograms to be combined,  and output histogram name" << endl;
    return -1;
  }

  string input_file=argv[1];
  string input_histnames=argv[2];
  TString output_file=argv[3];

  cout << "Reading input filelist from: " << input_file << endl;
  if (readFilelist(input_file) < 0 ) return -1;

  cout << "Reading list of histograms to combine from: " << input_histnames << endl;
  if (readHistNames(input_histnames) < 0 ) return -1;

  // open the rootfiles for reading and store their pointers
  vector<TFile*> rpointers;
  for (uint ifile=0; ifile != rootfiles.size(); ++ifile){
    TString rootname = rootfiles[ifile];
    TFile *file = new TFile(rootname);
    if(file->IsZombie()){
      std::cout << " *** Error opening file " << rootname << std::endl;
      return -1;
    }
    rpointers.push_back(file);
    cout << rootname 
	 << "  Weight: " << xsweightforfile[ifile] 
	 << "  Number of Entries: " << eventsinfile[ifile] 
	 << endl;
  }


  TObjArray Hlist(0);  // output list of histograms
  vector <TH1F*> h_copies;
  for (uint ihist=0; ihist != histnames.size(); ++ihist){ // loop over histograms

    TString hname=histnames[ihist];
    TH1F* copy_h=0;

    for (uint ifile=0; ifile != rootfiles.size(); ++ifile){ // loop over files

      TFile *rootfile=rpointers[ifile];
      TH1F *h_tmp=GetHist(rootfile,hname);
      if (!h_tmp) return -1;

      if (ifile ==0){
	copy_h = (TH1F*)h_tmp->Clone(hname + "_combined");
	copy_h->Reset();
	Hlist.Add(copy_h);
	h_copies.push_back(copy_h);
      }

      Double_t fact=xsweightforfile[ifile]/eventsinfile[ifile];
      h_tmp->Scale(fact); // scale histogram
      copy_h=h_copies[ihist];
      if (copy_h) copy_h->Add(h_tmp); // Add the histograms

    } // end of loop over files
  } // end of loop over histograms

  cout << "Writing output histograms to: " << output_file << endl;
  TFile f(output_file,"RECREATE");

  f.cd();
  Hlist.Write();
  f.ls();
  f.Close();

  return 0;

}
