#include <TFile.h>
#include <vector>
#include <map>
#include <string>
#include "TH1.h"
#include <sstream>
#include <iostream>
#include "Riostream.h"

std::vector<TString> rootfiles;
std::vector<int> eventsinfile;
std::vector<double> xsweightforfile;

std::vector<TString> histnames;
const size_t ntrigs=44;
const TString trignames[ntrigs] = {
  "UnTrig",
  "HLT1jet"    ,"HLT2jet"       ,"HLT3jet"      ,"HLT4jet"    ,"HLT1MET",
  "HLT2jetAco" ,"HLT1jet1METAco","HLT1jet1MET"  ,"HLT2jet1MET","HLT3jet1MET",
  "HLT4jet1MET","HLT1MET1HT"    ,"HLT1jetPE1"   ,"HLT1jetPE3" ,"HLT1jetPE5",

  "HLT1corjet"       ,"HLT2corjet"      ,"HLT3corjet"    ,"HLT4corjet"    , "HLT2corjetAco" ,
  "HLT1corjet1METAco","HLT1corjet1MET"  ,"HLT2corjet1MET","HLT3corjet1MET","HLT4corjet1MET",
  "HLT1corjetPE1"    ,"HLT1corjetPE3"   ,"HLT1corjetPE5",

  "L11jet"        ,"L12jet"       ,"L13jet"     ,"L14jet"     ,"L11MET"    ,
  "L12jetAco"     ,"L11jet1METAco","L11jet1MET" ,"L12jet1MET" ,"L13jet1MET",
  "L14jet1MET"    ,"L11MET1HT"    ,"L11jetPE1"  ,"L11jetPE3"  ,"L11jetPE5"  
};
  
int readFilelist(std::string filelist){
  int istat=0; //assume success

  std::string CommentLine="#"; // treat lines that begin with "#" as comment lines
  ifstream in;

  string input_line,word,filename;

  in.open(filelist.c_str());
  if (!in){
    cerr << "%Could not open file: " << filelist << endl;
    cerr << "%Terminating program" << endl;
    return -1;
  }

  //  while (1) {
  while (getline(in,input_line)){

    if (!in.good()) break;

    uint p1 = input_line.find (CommentLine,0);
    if ( p1 == std::string::npos){
      istringstream stream(input_line);
      std::vector<string> elements;

      while (stream >> word) {
	elements.push_back(word);
      }
      if (elements.size() >= 3){
	rootfiles.push_back(elements[0]);
	xsweightforfile.push_back(atof(elements[1].c_str()));
	eventsinfile.push_back(atoi(elements[2].c_str()));
      } 
      else {
	cout << "Error parsing input filelist" << endl;
	return -1;
      }
    }

  }
  return istat;

}


int readHistNames(std::string filelist){
  int istat=0; //assume success

  std::string CommentLine="#"; // treat lines that begin with "#" as comment lines
  ifstream in;

  string input_line;

  in.open(filelist.c_str());
  while (getline(in,input_line)){

    if (!in.good()) break;
    uint p1 = input_line.find (CommentLine,0);
    if ( p1 == std::string::npos){
	histnames.push_back(input_line);
    }
  }
  return istat;

}

std::string extractPtbin(std::string str){
  std::string ptbin="xxx";

  std::string StringToFind="pt";
  int ilen=StringToFind.size();
  uint p1 = str.find (StringToFind,0);
  if (p1 == std::string::npos) {
    std::cout << "Not found" << std::endl;
    return ptbin;
  }
  p1=p1+ilen;

  uint p2 = str.find (".root",0);
  if (p2 == std::string::npos) {
    std::cout << "Not found" << std::endl;
    return ptbin;
  }
  p2=p2-(p1);  
  ptbin=str.substr(p1,p2);
  std::cout << "Pt: " << ptbin << std::endl;

  return ptbin;
}

bool hExist(TFile *file,const TString& hname){

  bool retval=true;

  TKey *key = file->FindKey(hname);
  if (key ==0){
    std::cout << "!!Histogram " << hname << " does not exist!!" << std::endl;
    retval=false;
  }
  return retval;
}

TH1F* GetHist(TFile* file,const TString& hname){

  TH1F* h=0;
  if (hExist(file,hname)){
    h=(TH1F*)file->Get(hname);
  }

  return h;
}
